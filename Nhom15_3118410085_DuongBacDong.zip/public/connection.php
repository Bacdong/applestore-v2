<?php
    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'applestore';

    $connection = new mysqli($servername, $username, $password, $dbname);
?>